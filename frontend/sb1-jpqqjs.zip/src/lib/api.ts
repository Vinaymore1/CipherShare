const API_URL = 'http://localhost:3000/api/files';

export const api = {
  async uploadFiles(files: FileList) {
    const formData = new FormData();
    Array.from(files).forEach(file => {
      formData.append('files', file);
    });

    const response = await fetch(`${API_URL}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) throw new Error('Failed to upload files');
    return response.json();
  },

  async shareText(text: string) {
    const response = await fetch(`${API_URL}/share-text`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) throw new Error('Failed to share text');
    return response.json();
  },

  async retrieveFile(code: string) {
    const response = await fetch(`${API_URL}/retrieve/${code}`);
    if (!response.ok) throw new Error('Failed to retrieve file');
    return response.json();
  },

  async retrieveText(code: string) {
    const response = await fetch(`${API_URL}/retrieve-text/${code}`);
    if (!response.ok) throw new Error('Failed to retrieve text');
    return response.json();
  },

  getDownloadUrl(code: string) {
    return `${API_URL}/download/${code}`;
  },
};