import { Link } from 'react-router-dom';
import { Shield, Upload, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ModeToggle } from '@/components/mode-toggle';

export default function Navbar() {
  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center px-4">
        <Link to="/" className="flex items-center space-x-2 group">
          <div className="relative">
            <Shield className="h-8 w-8 text-primary transition-colors group-hover:text-primary/90" />
            <Shield className="absolute inset-0 h-8 w-8 text-primary/20 blur-[2px] transition-all group-hover:blur-[4px]" />
          </div>
          <div className="flex flex-col -space-y-1">
            <span className="text-xl font-bold tracking-tight">CipherShare</span>
            <span className="text-xs text-muted-foreground">Secure File Transfer</span>
          </div>
        </Link>
        <div className="flex-1" />
        <div className="flex items-center space-x-4">
          <Link to="/share">
            <Button variant="ghost" size="sm" className="hover:bg-primary/10">
              <Upload className="mr-2 h-4 w-4" />
              Share
            </Button>
          </Link>
          <Link to="/retrieve">
            <Button variant="ghost" size="sm" className="hover:bg-primary/10">
              <Download className="mr-2 h-4 w-4" />
              Retrieve
            </Button>
          </Link>
          <ModeToggle />
        </div>
      </div>
    </nav>
  );
}