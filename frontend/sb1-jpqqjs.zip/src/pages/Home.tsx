import { Link } from 'react-router-dom';
import { Shield, Upload, Download, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

export default function Home() {
  return (
    <div className="flex flex-col items-center space-y-12 py-12">
      <div className="text-center space-y-6">
        <div className="flex justify-center">
          <div className="relative">
            <Shield className="h-20 w-20 text-primary animate-pulse" />
            <Shield className="absolute inset-0 h-20 w-20 text-primary/20 blur-[4px]" />
          </div>
        </div>
        <div className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
            CipherShare
          </h1>
          <p className="text-2xl font-semibold text-muted-foreground">
            Secure File Sharing Made Simple
          </p>
        </div>
        <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
          Share files and text securely with end-to-end encryption.
          Your data, your control.
        </p>
        <div className="flex justify-center gap-4">
          <Link to="/share">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              <Upload className="mr-2 h-5 w-5" />
              Share Files
            </Button>
          </Link>
          <Link to="/retrieve">
            <Button size="lg" variant="outline" className="hover:bg-primary/10">
              <Download className="mr-2 h-5 w-5" />
              Retrieve Files
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-primary" />
              End-to-End Encryption
            </CardTitle>
            <CardDescription>Your files are encrypted before upload</CardDescription>
          </CardHeader>
          <CardContent>
            <Lock className="h-12 w-12 text-primary/80" />
          </CardContent>
        </Card>
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-primary" />
              No Registration
            </CardTitle>
            <CardDescription>Share files instantly without an account</CardDescription>
          </CardHeader>
          <CardContent>
            <Upload className="h-12 w-12 text-primary/80" />
          </CardContent>
        </Card>
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Secure Access
            </CardTitle>
            <CardDescription>Access files with unique codes or links</CardDescription>
          </CardHeader>
          <CardContent>
            <Shield className="h-12 w-12 text-primary/80" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}