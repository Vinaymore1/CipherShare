import { useState } from 'react';
import { Upload, Copy, Check, FileText, File, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { FileDropzone } from '@/components/FileDropzone';
import { api } from '@/lib/api';

export default function Share() {
  const [files, setFiles] = useState<FileList | null>(null);
  const [text, setText] = useState('');
  const [shareCode, setShareCode] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleShare = async () => {
    setIsLoading(true);
    try {
      let response;
      if (files) {
        response = await api.uploadFiles(files);
      } else {
        response = await api.shareText(text);
      }
      setShareCode(response.code.toString());
      toast.success(files ? 'Files uploaded successfully!' : 'Text shared successfully!');
    } catch (error) {
      toast.error('Failed to share content');
      console.error('Share error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
    toast.success('Code copied to clipboard!');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <Card className="border-primary/20">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-primary" />
            <CardTitle>Share Content Securely</CardTitle>
          </div>
          <CardDescription>
            Your files and messages are encrypted end-to-end for maximum security
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="files" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="files" className="flex items-center gap-2">
                <File className="h-4 w-4" />
                Files
              </TabsTrigger>
              <TabsTrigger value="text" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Text
              </TabsTrigger>
            </TabsList>

            <TabsContent value="files" className="space-y-6">
              <div className="space-y-2">
                <Label>Upload Files</Label>
                <FileDropzone files={files} onFilesChange={setFiles} />
              </div>
              <Button
                className="w-full bg-primary hover:bg-primary/90"
                onClick={handleShare}
                disabled={!files || isLoading}
              >
                <Upload className="mr-2 h-4 w-4" />
                {isLoading ? 'Encrypting & Uploading...' : 'Encrypt & Upload Files'}
              </Button>
            </TabsContent>

            <TabsContent value="text" className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="text">Message</Label>
                <Textarea
                  id="text"
                  placeholder="Enter your message to share securely..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="min-h-[200px]"
                />
              </div>
              <Button
                className="w-full bg-primary hover:bg-primary/90"
                onClick={handleShare}
                disabled={!text.trim() || isLoading}
              >
                <Upload className="mr-2 h-4 w-4" />
                {isLoading ? 'Encrypting & Sharing...' : 'Encrypt & Share Message'}
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {shareCode && (
        <Card className="border-primary/20">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-primary" />
              <CardTitle>Secure Share Code</CardTitle>
            </div>
            <CardDescription>
              Share this code with others to let them access your {files ? 'files' : 'message'}.
              The code is valid for 24 hours.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Input 
                value={shareCode} 
                readOnly 
                className="font-mono text-lg text-center bg-muted"
              />
              <Button 
                variant="outline" 
                size="icon"
                onClick={copyToClipboard}
                className="hover:bg-primary/10 hover:text-primary"
              >
                {isCopied ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <Shield className="h-4 w-4" />
              This code is encrypted and can only be used once for security
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}