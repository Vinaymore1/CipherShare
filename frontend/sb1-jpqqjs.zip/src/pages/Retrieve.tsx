import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Download, Search, FileText, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import { api } from '@/lib/api';

interface SharedContent {
  type: 'files' | 'text';
  content: string;
  downloadUrl?: string;
}

export default function Retrieve() {
  const { code: urlCode } = useParams();
  const navigate = useNavigate();
  const [code, setCode] = useState(urlCode || '');
  const [isLoading, setIsLoading] = useState(false);
  const [content, setContent] = useState<SharedContent | null>(null);

  useEffect(() => {
    if (urlCode) {
      handleRetrieve();
    }
  }, [urlCode]);

  const handleRetrieve = async () => {
    if (!code) return;
    
    setIsLoading(true);
    try {
      // Try to retrieve text first
      try {
        const textResponse = await api.retrieveText(code);
        setContent({
          type: 'text',
          content: textResponse.text
        });
      } catch {
        // If text retrieval fails, try file
        const fileResponse = await api.retrieveFile(code);
        setContent({
          type: 'files',
          content: 'File ready for download',
          downloadUrl: fileResponse.downloadUrl
        });
      }
      toast.success('Content retrieved successfully!');
    } catch (error) {
      console.error('Retrieve error:', error);
      toast.error('Failed to retrieve content');
      setContent(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code) {
      navigate(`/retrieve/${code}`);
    }
  };

  const handleDownload = () => {
    if (content?.downloadUrl) {
      window.location.href = content.downloadUrl;
      toast.success('Download started');
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Retrieve Shared Content</CardTitle>
          <CardDescription>
            Enter the share code to access files or messages
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="code">Share Code</Label>
              <div className="flex space-x-2">
                <Input
                  id="code"
                  placeholder="Enter share code..."
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                />
                <Button type="submit" disabled={!code || isLoading}>
                  <Search className="mr-2 h-4 w-4" />
                  {isLoading ? 'Finding...' : 'Find'}
                </Button>
              </div>
            </div>
          </form>

          {content && (
            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-2 mb-4">
                {content.type === 'files' ? (
                  <File className="h-5 w-5 text-primary" />
                ) : (
                  <FileText className="h-5 w-5 text-primary" />
                )}
                <h3 className="text-lg font-semibold">
                  {content.type === 'files' ? 'Shared Files' : 'Shared Message'}
                </h3>
              </div>

              {content.type === 'text' ? (
                <Card>
                  <CardContent className="pt-6">
                    <p className="whitespace-pre-wrap">{content.content}</p>
                  </CardContent>
                </Card>
              ) : (
                <Button 
                  className="w-full bg-primary hover:bg-primary/90" 
                  onClick={handleDownload}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Files
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}